package database;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.gson.Gson;

import model.Line;
import model.User;
import redis.clients.jedis.Jedis;

public class RedisDatabase {
	private static List  lines=new ArrayList() ;
	private static Gson gson;
	private static Jedis jedis;
	static
	{
		 jedis=new Jedis("localhost");
		 gson=new Gson();
		 lines.add(new Line("linija#1", new String[]{"A 16:30","B 16:45"}));
		 lines.add(new Line("linija#2", new String[]{"B 16:30","C 16:45","D 17:00"}));
		 lines.add(new Line("linija#3", new String[]{"B 9:00","D 9:20","E 9:25"}));
		 lines.add(new Line("linija#4", new String[]{"A 7:00","C 7:20","D 7:35"}));
		 for(int i=0;i<lines.size();i++) {
		 jedis.set(((Line) lines.get(i)).getSign(),gson.toJson(((Line) lines.get(i)).getStations()));
		 }
		 
	}
public static void main(String [] args) {
	System.out.println(jedis.get("linija#5"));
}
	
	public  boolean addLineInDatabase(String line) {
		Line l=gson.fromJson(line, Line.class);
		if(jedis.set(l.getSign(),gson.toJson(l.getStations())) != null) {
			return true;
		}
		return false;
	}
	public String getLineFromDatbase(String signOfStation) {
		String line="";
		Set<String>keys=jedis.keys("linija#*");
		Iterator<String> it = keys.iterator();
	    while (it.hasNext()) {
	        String key = it.next();
	        
	        String value=gson.fromJson(jedis.get(key),String.class);
	        if(value.contains(signOfStation)) {
	        	line+=key+";"+value+";";
	        }
	    }
		return line;
	}

	public List<Line> getAllLines() {
		return jedis.keys("linija#*")
					.stream()
					.map(jedis::get)
					.map(elem -> gson.fromJson(elem, Line.class))
					.collect(Collectors.toList());
	}
	
}
